var fontx_8h =
[
    [ "FontxGlyphBufSize", "fontx_8h.html#a2b6faf212a76ed7ab3cb7f16357e1f27", null ],
    [ "FILE", "group__FONTX.html#ga912af5ab9f8a52ddd387b7defc0b49f1", null ],
    [ "AaddFontx", "group__FONTX.html#ga0e63a8c8099efe0ec241e8e919103d7d", null ],
    [ "CloseFontx", "group__FONTX.html#ga67d6e286011132d6c8e442e56e6c130f", null ],
    [ "DumpFontx", "group__FONTX.html#ga2425c76d454d2efaa17444a5cc1ee99f", null ],
    [ "Font2Bitmap", "group__FONTX.html#gac1d318d453f0aa890880e1929c2f0d9a", null ],
    [ "GetFontHeight", "group__FONTX.html#gae2e382fd90550579bc33f85839b544aa", null ],
    [ "GetFontWidth", "group__FONTX.html#ga9f10db7e15c7d765c501a59f13b4e2ab", null ],
    [ "GetFontx", "group__FONTX.html#ga70d9af862f8906a3bedb6cc10b46f3f6", null ],
    [ "InitFontx", "group__FONTX.html#ga56c14428c1129949e8c6c29b1f314f23", null ],
    [ "OpenFontx", "group__FONTX.html#gad919094a18ac1d85c85f741c31a3dc00", null ],
    [ "ReversBitmap", "group__FONTX.html#ga95e50bd8ef1d30c7a1915eaad0404c86", null ],
    [ "RotateByte", "group__FONTX.html#ga78ff021f7f07c95d125835eb427f0f26", null ],
    [ "ShowBitmap", "group__FONTX.html#ga6a6e219ff7b98007aeb3d63bf23ca2f7", null ],
    [ "ShowFont", "group__FONTX.html#gaa1146bd5b76f1b1abf84a91620e45f30", null ],
    [ "UnderlineBitmap", "group__FONTX.html#gadbc0ddfc2914b36535572c05e6b79232", null ]
];