var group__LOG =
[
    [ "pynq_error", "group__LOG.html#gadfb41534b2e47021af72120cdceab934", null ],
    [ "pynq_info", "group__LOG.html#ga28d0314d4d22a476d97a372e8f7e0131", null ],
    [ "pynq_warning", "group__LOG.html#gae450bd7cf8541336514438e344b82f7a", null ],
    [ "LogLevel", "group__LOG.html#ga5014459d5368b638041dc2a6ee565356", null ],
    [ "LogLevel", "group__LOG.html#gaca1fd1d8935433e6ba2e3918214e07f9", [
      [ "LOG_LEVEL_INFO", "group__LOG.html#ggaca1fd1d8935433e6ba2e3918214e07f9aedee1e3159bfe7d918b6e29873c5aee4", null ],
      [ "LOG_LEVEL_WARNING", "group__LOG.html#ggaca1fd1d8935433e6ba2e3918214e07f9a5b4dd81b4dc7eefbc55ba03415c627ef", null ],
      [ "LOG_LEVEL_ERROR", "group__LOG.html#ggaca1fd1d8935433e6ba2e3918214e07f9a5b40f003febbc3b535649d63f4b8a44f", null ],
      [ "NUM_LOG_LEVELS", "group__LOG.html#ggaca1fd1d8935433e6ba2e3918214e07f9a4ffba60acdbb6fe4c6acf32b06d065d0", null ]
    ] ],
    [ "pynq_log", "group__LOG.html#ga190ef46bdfa0f8b5bddb785f2b685673", null ]
];