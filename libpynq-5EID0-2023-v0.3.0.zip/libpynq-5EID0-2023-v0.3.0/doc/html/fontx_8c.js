var fontx_8c =
[
    [ "FontxDebug", "fontx_8c.html#a7ddc949c2147f61bf01b9f72b684cf1a", null ],
    [ "AddFontx", "fontx_8c.html#ac9eb3a2c7281557788affe0466dda66c", null ],
    [ "CloseFontx", "group__FONTX.html#ga67d6e286011132d6c8e442e56e6c130f", null ],
    [ "DumpFontx", "group__FONTX.html#ga2425c76d454d2efaa17444a5cc1ee99f", null ],
    [ "Font2Bitmap", "group__FONTX.html#gac1d318d453f0aa890880e1929c2f0d9a", null ],
    [ "GetFontx", "group__FONTX.html#ga70d9af862f8906a3bedb6cc10b46f3f6", null ],
    [ "getFortHeight", "fontx_8c.html#adcd0e9be891eaa8c7c5cfae9359179c7", null ],
    [ "getFortWidth", "fontx_8c.html#afb926fc255f7043456ba8acc2be4e591", null ],
    [ "InitFontx", "group__FONTX.html#ga56c14428c1129949e8c6c29b1f314f23", null ],
    [ "OpenFontx", "group__FONTX.html#gad919094a18ac1d85c85f741c31a3dc00", null ],
    [ "ReversBitmap", "group__FONTX.html#ga95e50bd8ef1d30c7a1915eaad0404c86", null ],
    [ "RotateByte", "group__FONTX.html#ga78ff021f7f07c95d125835eb427f0f26", null ],
    [ "ShowBitmap", "group__FONTX.html#ga6a6e219ff7b98007aeb3d63bf23ca2f7", null ],
    [ "ShowFont", "group__FONTX.html#gaa1146bd5b76f1b1abf84a91620e45f30", null ],
    [ "UnderlineBitmap", "group__FONTX.html#gadbc0ddfc2914b36535572c05e6b79232", null ]
];