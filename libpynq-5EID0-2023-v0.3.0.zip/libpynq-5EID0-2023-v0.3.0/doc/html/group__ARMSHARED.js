var group__ARMSHARED =
[
    [ "arm_shared_t", "structarm__shared__t.html", [
      [ "address", "structarm__shared__t.html#aeea937d10e63d6218c4ad7cfc2c619c5", null ],
      [ "file_descriptor", "structarm__shared__t.html#a73bb1611ec7df55b9b986af1cd288201", null ],
      [ "length", "structarm__shared__t.html#a3497930a71fd13db6cb1cf4026c15379", null ],
      [ "mmaped_region", "structarm__shared__t.html#a8cdf9fb06e80f6dfadd2d1f03994bf1b", null ]
    ] ],
    [ "arm_shared", "group__ARMSHARED.html#gab7df4784402eed6d78088da9f07f0ab4", null ],
    [ "arm_shared_close", "group__ARMSHARED.html#ga12c3557dfcb0ebbf3386b52068c56618", null ],
    [ "arm_shared_init", "group__ARMSHARED.html#gab5254fff75e33f677c5a4b0c0f401f10", null ]
];