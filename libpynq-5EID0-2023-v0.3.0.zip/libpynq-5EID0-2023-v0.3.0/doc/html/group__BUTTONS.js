var group__BUTTONS =
[
    [ "BUTTON_NOT_PUSHED", "group__BUTTONS.html#ga443698782d954e8e4c5822cdf9f7dc2d", null ],
    [ "BUTTON_PUSHED", "group__BUTTONS.html#ga8cf3f6cc2a9740f6ce8f69e2a15cf399", null ],
    [ "SWITCH_OFF", "group__BUTTONS.html#ga0840b1ea467b887a5268c32c5fdcd7d5", null ],
    [ "SWITCH_ON", "group__BUTTONS.html#ga3027aae495fb6502790df1ed3aa8d133", null ],
    [ "button_index_t", "group__BUTTONS.html#ga711eeb98ffdbaaaeed9fd7b659b3d83b", [
      [ "BUTTON0", "group__BUTTONS.html#gga711eeb98ffdbaaaeed9fd7b659b3d83ba434a9ffaf13a68c3f80598545c267974", null ],
      [ "BUTTON1", "group__BUTTONS.html#gga711eeb98ffdbaaaeed9fd7b659b3d83baa9b981eb5c922bb8a465ed598570326e", null ],
      [ "BUTTON2", "group__BUTTONS.html#gga711eeb98ffdbaaaeed9fd7b659b3d83bab4847e21b0ec42aa5494cfca68e0fd7d", null ],
      [ "BUTTON3", "group__BUTTONS.html#gga711eeb98ffdbaaaeed9fd7b659b3d83bab54d1da4e24832ef82c095b0a77b5cb9", null ],
      [ "NUM_BUTTONS", "group__BUTTONS.html#gga711eeb98ffdbaaaeed9fd7b659b3d83bac81067fe4db9cdff7042b4d9efb5f4cb", null ]
    ] ],
    [ "switches_index_t", "group__BUTTONS.html#ga426bebe7ddc81f4c7a7e1853b20fe17b", [
      [ "SWITCH0", "group__BUTTONS.html#gga426bebe7ddc81f4c7a7e1853b20fe17baa21732d97fc87fe6f44d332d5deedd04", null ],
      [ "SWITCH1", "group__BUTTONS.html#gga426bebe7ddc81f4c7a7e1853b20fe17bab16bac9024d0eedded8fd873e9d40328", null ],
      [ "NUM_SWITCHES", "group__BUTTONS.html#gga426bebe7ddc81f4c7a7e1853b20fe17ba30feaf3abb229ebb97fce793cbecae56", null ]
    ] ],
    [ "buttons_destroy", "group__BUTTONS.html#ga3633aee67ac18052de38fb71d13811f3", null ],
    [ "buttons_init", "group__BUTTONS.html#gacef6dd444cb6560da652897ee43ab306", null ],
    [ "get_button_state", "group__BUTTONS.html#gacc476636216862a61ee78201a3bbe92f", null ],
    [ "get_switch_state", "group__BUTTONS.html#gac9f62ce663ac190adcc8f2a1df5922fd", null ],
    [ "sleep_msec_button_pushed", "group__BUTTONS.html#ga0cfd4ec403dbb078a31457c34d8e1268", null ],
    [ "sleep_msec_buttons_pushed", "group__BUTTONS.html#gaf3139cee17ab0d39792d4ed111173854", null ],
    [ "switches_destroy", "group__BUTTONS.html#ga6fd5f582221b6e55722ed8651fcd3617", null ],
    [ "switches_init", "group__BUTTONS.html#ga1e5ebcb346c25e1755e3ccb1e9f3c9f9", null ],
    [ "wait_until_any_button_pushed", "group__BUTTONS.html#ga3249cfa7eaa3dc7217b466e2bd1d6067", null ],
    [ "wait_until_any_button_released", "group__BUTTONS.html#ga5c79a6880ef76e1f96407fb9a1aa8774", null ],
    [ "wait_until_button_pushed", "group__BUTTONS.html#ga1635729112b5af83feee6a4255cc2373", null ],
    [ "wait_until_button_released", "group__BUTTONS.html#gaa3646a1a39ebd3d5d8f375c4352e4d8b", null ],
    [ "wait_until_button_state", "group__BUTTONS.html#ga75a555075662ca2a8a4be526adeb37b3", null ]
];