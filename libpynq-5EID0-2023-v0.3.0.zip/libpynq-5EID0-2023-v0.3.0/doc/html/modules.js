var modules =
[
    [ "ADC library", "group__ADC.html", "group__ADC" ],
    [ "ARM MMIO library", "group__ARMSHARED.html", "group__ARMSHARED" ],
    [ "Audio library", "group__AUDIO.html", "group__AUDIO" ],
    [ "Button library", "group__BUTTONS.html", "group__BUTTONS" ],
    [ "Display library", "group__DISPLAY.html", "group__DISPLAY" ],
    [ "Font library", "group__FONTX.html", "group__FONTX" ],
    [ "GPIO library", "group__GPIO.html", "group__GPIO" ],
    [ "IIC library", "group__IIC.html", "group__IIC" ],
    [ "Interrupt library", "group__INTERRUPTS.html", "group__INTERRUPTS" ],
    [ "LED library", "group__LEDS.html", "group__LEDS" ],
    [ "Logging library", "group__LOG.html", "group__LOG" ],
    [ "I/O pin mapping", "group__PINMAP.html", "group__PINMAP" ],
    [ "PULSECOUNTER library", "group__PULSECOUNTER.html", "group__PULSECOUNTER" ],
    [ "PWM library", "group__PWM.html", "group__PWM" ],
    [ "STEPPER library", "group__STEPPER.html", "group__STEPPER" ],
    [ "I/O Switchbox library", "group__SWITCHBOX.html", "group__SWITCHBOX" ],
    [ "UART library", "group__UART.html", "group__UART" ],
    [ "Utility library", "group__UTIL.html", "group__UTIL" ],
    [ "Versioning library", "group__VERSION.html", "group__VERSION" ]
];