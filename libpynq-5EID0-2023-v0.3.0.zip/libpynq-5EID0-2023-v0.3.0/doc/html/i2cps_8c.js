var i2cps_8c =
[
    [ "readI2C_asFile", "i2cps_8c.html#abf82e1e8e8f7974695f541af2526357a", null ],
    [ "setI2C", "i2cps_8c.html#a423d97e7bbc2c26785d9a5de31d2f220", null ],
    [ "unsetI2C", "i2cps_8c.html#a8fbf09bd758928bc8f434d96957ec40f", null ],
    [ "writeI2C_asFile", "i2cps_8c.html#a655bf0c0118a9dff569ee054c0a395f1", null ]
];