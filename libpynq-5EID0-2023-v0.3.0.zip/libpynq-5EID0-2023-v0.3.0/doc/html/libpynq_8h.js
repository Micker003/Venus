var libpynq_8h =
[
    [ "pynq_destroy", "libpynq_8h.html#ac2fc79c63b22d4ce66226ca5d36d8577", null ],
    [ "pynq_init", "libpynq_8h.html#a3c76b9633e9988436c3e3555be805728", null ]
];