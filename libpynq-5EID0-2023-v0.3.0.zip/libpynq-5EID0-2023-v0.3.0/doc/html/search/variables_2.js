var searchData=
[
  ['bc_1063',['bc',['../structFontxFile.html#a2238ecad9dcd978769bd8265f099e195',1,'FontxFile']]]
];
