var searchData=
[
  ['channel_67',['channel',['../structpin.html#ac01efb4bbda45e65d308aefe61e892a7',1,'pin::channel()'],['../structpin__state__t.html#aca29782c986ac13b0ba2c0825d9dd67f',1,'pin_state_t::channel()']]],
  ['check_5fchannel_5fadc_68',['check_channel_adc',['../adc_8c.html#af1193b8b8fc22626189c3de755e9fd6e',1,'adc.c']]],
  ['check_5finitialization_69',['check_initialization',['../interrupt_8c.html#a9b67e3d1a1cb47210459207e80747ad1',1,'interrupt.c']]],
  ['check_5finitialized_5fadc_70',['check_initialized_adc',['../adc_8c.html#abfec0c3da1defecc0e7f60079f6e59eb',1,'adc.c']]],
  ['check_5finitialized_5fpwm_71',['check_initialized_pwm',['../pwm_8c.html#abcae3c5f25f1aec206ba8f64f0bed39e',1,'pwm.c']]],
  ['check_5fversion_72',['check_version',['../group__VERSION.html#ga4ab7d615706bed1f5785b78a216b6615',1,'check_version(void):&#160;version.c'],['../group__VERSION.html#ga4ab7d615706bed1f5785b78a216b6615',1,'check_version(void):&#160;version.c']]],
  ['closefontx_73',['CloseFontx',['../group__FONTX.html#ga67d6e286011132d6c8e442e56e6c130f',1,'CloseFontx(FontxFile *fx):&#160;fontx.c'],['../group__FONTX.html#ga67d6e286011132d6c8e442e56e6c130f',1,'CloseFontx(FontxFile *fx):&#160;fontx.c']]],
  ['color_5fled0_74',['COLOR_LED0',['../group__LEDS.html#gga5d0e2415131d5a46bf054c9adfafd12daa904ee289032d5569f7a54d7e09e560a',1,'leds.h']]],
  ['color_5fled1_75',['COLOR_LED1',['../group__LEDS.html#gga5d0e2415131d5a46bf054c9adfafd12da8d321151b19bbcbe86e91c86bccac8dc',1,'leds.h']]],
  ['color_5fled_5fblue_5fonoff_76',['color_led_blue_onoff',['../group__LEDS.html#ga692d47d5ac4d6699faf94e76e9b7a4a3',1,'color_led_blue_onoff(const int onoff):&#160;leds.c'],['../group__LEDS.html#ga692d47d5ac4d6699faf94e76e9b7a4a3',1,'color_led_blue_onoff(const int onoff):&#160;leds.c']]],
  ['color_5fled_5fgreen_5fonoff_77',['color_led_green_onoff',['../group__LEDS.html#ga82bb7a9d695a458db2b1f62c6af1e7b1',1,'color_led_green_onoff(const int onoff):&#160;leds.c'],['../group__LEDS.html#ga82bb7a9d695a458db2b1f62c6af1e7b1',1,'color_led_green_onoff(const int onoff):&#160;leds.c']]],
  ['color_5fled_5findex_5ft_78',['color_led_index_t',['../group__LEDS.html#ga5d0e2415131d5a46bf054c9adfafd12d',1,'leds.h']]],
  ['color_5fled_5foff_79',['color_led_off',['../group__LEDS.html#ga3684a353eff418c4a8c4c78511696643',1,'color_led_off(void):&#160;leds.c'],['../group__LEDS.html#ga3684a353eff418c4a8c4c78511696643',1,'color_led_off(void):&#160;leds.c']]],
  ['color_5fled_5fon_80',['color_led_on',['../group__LEDS.html#ga666cdfc77d5728bb2e3991314a81dc65',1,'color_led_on(void):&#160;leds.c'],['../group__LEDS.html#ga666cdfc77d5728bb2e3991314a81dc65',1,'color_led_on(void):&#160;leds.c']]],
  ['color_5fled_5fonoff_81',['color_led_onoff',['../group__LEDS.html#ga17a899bd719b38cfad2b6c69dd75b7ef',1,'color_led_onoff(const int red_onoff, const int green_onoff, const int blue_onoff):&#160;leds.c'],['../group__LEDS.html#ga17a899bd719b38cfad2b6c69dd75b7ef',1,'color_led_onoff(const int red_onoff, const int green_onoff, const int blue_onoff):&#160;leds.c']]],
  ['color_5fled_5fred_5fonoff_82',['color_led_red_onoff',['../group__LEDS.html#ga34dee279f15866dcf3444ac236c06dcb',1,'color_led_red_onoff(const int onoff):&#160;leds.c'],['../group__LEDS.html#ga34dee279f15866dcf3444ac236c06dcb',1,'color_led_red_onoff(const int onoff):&#160;leds.c']]],
  ['color_5fleds_5finit_5fpwm_83',['color_leds_init_pwm',['../group__LEDS.html#gaa22a156ff7d5b4562bcffad72db710c3',1,'color_leds_init_pwm(void):&#160;leds.c'],['../group__LEDS.html#gaa22a156ff7d5b4562bcffad72db710c3',1,'color_leds_init_pwm(void):&#160;leds.c']]],
  ['colors_84',['colors',['../group__DISPLAY.html#gaedd64c3f92da850b93776c65fd1cced3',1,'display.h']]],
  ['config_5faudio_5fcodec_85',['config_audio_codec',['../group__AUDIO.html#ga4c3476adecb27a3162fabab4af088f0b',1,'config_audio_codec(void):&#160;audio.c'],['../group__AUDIO.html#ga4c3476adecb27a3162fabab4af088f0b',1,'config_audio_codec(void):&#160;audio.c']]],
  ['config_5faudio_5fpll_86',['config_audio_pll',['../group__AUDIO.html#ga9c9de79126611d05d3e2bda897ca886e',1,'config_audio_pll(void):&#160;audio.c'],['../group__AUDIO.html#ga9c9de79126611d05d3e2bda897ca886e',1,'config_audio_pll(void):&#160;audio.c']]]
];
