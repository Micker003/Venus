var searchData=
[
  ['directions_1128',['directions',['../group__DISPLAY.html#ga94c73cf6934fd835103f0f2794071ee9',1,'display.h']]]
];
