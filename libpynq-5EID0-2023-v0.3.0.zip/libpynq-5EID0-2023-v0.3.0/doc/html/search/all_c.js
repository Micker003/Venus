var searchData=
[
  ['opened_392',['opened',['../structFontxFile.html#abbe390075007bfcbf7b947107c13be9b',1,'FontxFile']]],
  ['openfontx_393',['OpenFontx',['../group__FONTX.html#gad919094a18ac1d85c85f741c31a3dc00',1,'OpenFontx(FontxFile *fx):&#160;fontx.c'],['../group__FONTX.html#gad919094a18ac1d85c85f741c31a3dc00',1,'OpenFontx(FontxFile *fx):&#160;fontx.c']]]
];
