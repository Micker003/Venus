var searchData=
[
  ['xiic_5faddrasslavefuncptr_1107',['XIic_AddrAsSlaveFuncPtr',['../xiic__i_8h.html#af4d37305c9a8e5c5963cde1f22429a56',1,'xiic_i.h']]],
  ['xiic_5farblostfuncptr_1108',['XIic_ArbLostFuncPtr',['../xiic__i_8h.html#a0e04ce38811487c6485ed3c9eaefa739',1,'xiic_i.h']]],
  ['xiic_5fbusnotbusyfuncptr_1109',['XIic_BusNotBusyFuncPtr',['../xiic__i_8h.html#ac5f5ace9ba703757e147c072256ad712',1,'xiic_i.h']]],
  ['xiic_5fconfigtable_1110',['XIic_ConfigTable',['../xiic__i_8h.html#a1650420711273450b9b406d43f10dd0d',1,'xiic_i.h']]],
  ['xiic_5fnotaddrasslavefuncptr_1111',['XIic_NotAddrAsSlaveFuncPtr',['../xiic__i_8h.html#a4dec2429ddab7bef35cc90c768aa2f5a',1,'xiic_i.h']]],
  ['xiic_5frecvmasterfuncptr_1112',['XIic_RecvMasterFuncPtr',['../xiic__i_8h.html#a406ec99e4f66ef8266ac18d05a24ee6c',1,'xiic_i.h']]],
  ['xiic_5frecvslavefuncptr_1113',['XIic_RecvSlaveFuncPtr',['../xiic__i_8h.html#afc5a9f589bb61c89a36a52f141d13ecd',1,'xiic_i.h']]],
  ['xiic_5fsendmasterfuncptr_1114',['XIic_SendMasterFuncPtr',['../xiic__i_8h.html#a9189a28a868ae80741633b044394a09b',1,'xiic_i.h']]],
  ['xiic_5fsendslavefuncptr_1115',['XIic_SendSlaveFuncPtr',['../xiic__i_8h.html#a6a45c687fc82770664024eda30cf8448',1,'xiic_i.h']]]
];
