var searchData=
[
  ['xiic_5fcheckisbusbusy_1042',['XIic_CheckIsBusBusy',['../xiic__l_8c.html#a666950a34ecedafb419839935b62fb7f',1,'XIic_CheckIsBusBusy(UINTPTR BaseAddress):&#160;xiic_l.c'],['../xiic__l_8h.html#a666950a34ecedafb419839935b62fb7f',1,'XIic_CheckIsBusBusy(UINTPTR BaseAddress):&#160;xiic_l.c']]],
  ['xiic_5fdyninit_1043',['XIic_DynInit',['../xiic__l_8h.html#a2834e01a7020d639b08d62cecec85bbe',1,'xiic_l.h']]],
  ['xiic_5fdynrecv_1044',['XIic_DynRecv',['../xiic__l_8h.html#a9979fbd483e1c8c495c9eb2bfd7ad6e9',1,'xiic_l.h']]],
  ['xiic_5fdynsend_1045',['XIic_DynSend',['../xiic__l_8h.html#adeaf11cda2466ae1c6036a3de0f52874',1,'xiic_l.h']]],
  ['xiic_5frecv_1046',['XIic_Recv',['../xiic__l_8c.html#a7a848238d75ff57837afa5a58f11f326',1,'XIic_Recv(UINTPTR BaseAddress, u8 Address, u8 *BufferPtr, unsigned ByteCount, u8 Option):&#160;xiic_l.c'],['../xiic__l_8h.html#a7a848238d75ff57837afa5a58f11f326',1,'XIic_Recv(UINTPTR BaseAddress, u8 Address, u8 *BufferPtr, unsigned ByteCount, u8 Option):&#160;xiic_l.c']]],
  ['xiic_5fsend_1047',['XIic_Send',['../xiic__l_8c.html#a907c577b53407fb0bfc98d0ca37ee221',1,'XIic_Send(UINTPTR BaseAddress, u8 Address, u8 *BufferPtr, unsigned ByteCount, u8 Option):&#160;xiic_l.c'],['../xiic__l_8h.html#a907c577b53407fb0bfc98d0ca37ee221',1,'XIic_Send(UINTPTR BaseAddress, u8 Address, u8 *BufferPtr, unsigned ByteCount, u8 Option):&#160;xiic_l.c']]],
  ['xiic_5ftransmitfifofill_1048',['XIic_TransmitFifoFill',['../xiic__i_8h.html#ab68f6a977445ce2895c94be4a0654ec1',1,'xiic_i.h']]],
  ['xiic_5fwaitbusfree_1049',['XIic_WaitBusFree',['../xiic__l_8c.html#a90f3806cf4817250596f6f68f2c066a3',1,'XIic_WaitBusFree(UINTPTR BaseAddress):&#160;xiic_l.c'],['../xiic__l_8h.html#a90f3806cf4817250596f6f68f2c066a3',1,'XIic_WaitBusFree(UINTPTR BaseAddress):&#160;xiic_l.c']]]
];
