var searchData=
[
  ['read_5faudio_5freg_986',['read_audio_reg',['../audio_8c.html#a543110eb76ac847e8be875e2cfb0fbc1',1,'audio.c']]],
  ['readi2c_5fasfile_987',['readI2C_asFile',['../i2cps_8c.html#abf82e1e8e8f7974695f541af2526357a',1,'readI2C_asFile(int i2c_fd, unsigned char readbuffer[], unsigned char bytes):&#160;i2cps.c'],['../i2cps_8h.html#abf82e1e8e8f7974695f541af2526357a',1,'readI2C_asFile(int i2c_fd, unsigned char readbuffer[], unsigned char bytes):&#160;i2cps.c']]],
  ['reversbitmap_988',['ReversBitmap',['../group__FONTX.html#ga95e50bd8ef1d30c7a1915eaad0404c86',1,'ReversBitmap(uint8_t *line, uint8_t w, uint8_t h):&#160;fontx.c'],['../group__FONTX.html#ga95e50bd8ef1d30c7a1915eaad0404c86',1,'ReversBitmap(uint8_t *line, uint8_t w, uint8_t h):&#160;fontx.c']]],
  ['rgb_5fconv_989',['rgb_conv',['../group__DISPLAY.html#ga774042bd8c58beccb41ba2d678559a3d',1,'rgb_conv(uint16_t r, uint16_t g, uint16_t b):&#160;display.c'],['../group__DISPLAY.html#ga774042bd8c58beccb41ba2d678559a3d',1,'rgb_conv(uint16_t r, uint16_t g, uint16_t b):&#160;display.c']]],
  ['rotatebyte_990',['RotateByte',['../group__FONTX.html#ga78ff021f7f07c95d125835eb427f0f26',1,'RotateByte(uint8_t ch1):&#160;fontx.c'],['../group__FONTX.html#ga78ff021f7f07c95d125835eb427f0f26',1,'RotateByte(uint8_t ch):&#160;fontx.c']]]
];
