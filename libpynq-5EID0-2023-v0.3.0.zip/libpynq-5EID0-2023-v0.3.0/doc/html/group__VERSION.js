var group__VERSION =
[
    [ "version_t", "structversion__t.html", [
      [ "major", "structversion__t.html#a416baed41342720bbbca73a2c7b4926f", null ],
      [ "minor", "structversion__t.html#ae0ceed5598105d0b6bef201bd06d910c", null ],
      [ "patch", "structversion__t.html#a373beea54fb411368dd1d6071d44ca92", null ],
      [ "release", "structversion__t.html#a3004e390ba6b016f7460fa49ba4d859a", null ]
    ] ],
    [ "check_version", "group__VERSION.html#ga4ab7d615706bed1f5785b78a216b6615", null ],
    [ "print_version", "group__VERSION.html#gac6230d495fc909bb61195c45f703d492", null ],
    [ "libpynq_version", "group__VERSION.html#gac8ea5bb63e77e6a0d2339ef017ab1b21", null ]
];