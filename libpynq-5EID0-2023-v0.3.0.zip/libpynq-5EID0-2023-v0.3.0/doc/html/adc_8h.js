var adc_8h =
[
    [ "adc_channel_t", "group__ADC.html#gaafc4060027875f8fe46242b0656d7814", [
      [ "ADC0", "group__ADC.html#ggaafc4060027875f8fe46242b0656d7814add0cc42ad708e87cf4dd8a5c43c94097", null ],
      [ "ADC1", "group__ADC.html#ggaafc4060027875f8fe46242b0656d7814a55d17f14e4a04efc3f0c5144fdb16a9d", null ],
      [ "ADC2", "group__ADC.html#ggaafc4060027875f8fe46242b0656d7814a246a534bca85a0d87ddcb59e28c55d32", null ],
      [ "ADC3", "group__ADC.html#ggaafc4060027875f8fe46242b0656d7814aae0370f8f308778a8f8aa5c26053bf63", null ],
      [ "ADC4", "group__ADC.html#ggaafc4060027875f8fe46242b0656d7814a2e9f047076bc235c6c38fecdc29cc2e9", null ],
      [ "ADC5", "group__ADC.html#ggaafc4060027875f8fe46242b0656d7814a019d472284d9531fbcfc28b7d5961e32", null ]
    ] ],
    [ "adc_destroy", "group__ADC.html#ga879cfdbd930b0d6cb3668d63a5a41265", null ],
    [ "adc_init", "group__ADC.html#ga2b815e6730e8723a6d1d06d9ef8f31c0", null ],
    [ "adc_read_channel", "group__ADC.html#ga3b240634d5b05f4081287644d6a8a60d", null ],
    [ "adc_read_channel_raw", "group__ADC.html#ga6445090781b49f628c788ba3d9745853", null ],
    [ "initialized_adc", "group__ADC.html#ga36aebf58ac4baaa01a3a2a6f3bc209e3", null ]
];