#pragma once

void destroy(void);

void loop(void);

gboolean setup(void);
