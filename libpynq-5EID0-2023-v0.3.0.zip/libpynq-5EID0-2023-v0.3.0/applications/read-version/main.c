#include <libpynq.h>

int main(void) {
  print_version();
  check_version();
  return EXIT_SUCCESS;
}
