#include <libpynq.h>

int main(void) {
  pynq_init();

  // your code here

  pynq_destroy();
  return EXIT_SUCCESS;
}
